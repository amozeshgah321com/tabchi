import React, { useState } from 'react';
import { Form, Input, Select, Button, message } from 'antd';
import axios from 'axios';

const { TextArea } = Input;
const { Option } = Select;

const AdminPanel = () => {
    const [form] = Form.useForm();

    const onFinish = async (values) => {
        try {
            const response = await axios.post('http://localhost:8000/admin/update-code', values);
            message.success(response.data.message);
            form.resetFields();
        } catch (error) {
            message.error(error.response?.data?.detail || 'خطا در ذخیره کد');
        }
    };

    return (
        <Form form={form} onFinish={onFinish} layout="vertical">
            <Form.Item
                name="code"
                label="کد"
                rules={[{ required: true, message: 'لطفا کد را وارد کنید' }]}
            >
                <TextArea rows={10} placeholder="کد خود را اینجا کپی کنید" />
            </Form.Item>
            <Form.Item
                name="target"
                label="هدف"
                rules={[{ required: true, message: 'لطفا هدف را انتخاب کنید' }]}
            >
                <Select>
                    <Option value="backend">Back-end (Python)</Option>
                    <Option value="frontend">Front-end (JSX/CSS)</Option>
                </Select>
            </Form.Item>
            <Form.Item
                name="section"
                label="بخش"
                rules={[{ required: true, message: 'لطفا بخش را انتخاب کنید' }]}
            >
                <Select>
                    <Option value="functions">توابع (api.py)</Option>
                    <Option value="components">کامپوننت‌ها (App.jsx)</Option>
                </Select>
            </Form.Item>
            <Form.Item
                name="password"
                label="رمز عبور"
                rules={[{ required: true, message: 'لطفا رمز عبور را وارد کنید' }]}
            >
                <Input.Password placeholder="رمز عبور مدیریت" />
            </Form.Item>
            <Form.Item>
                <Button type="primary" htmlType="submit">
                    ذخیره کد
                </Button>
            </Form.Item>
        </Form>
    );
};

export default AdminPanel;