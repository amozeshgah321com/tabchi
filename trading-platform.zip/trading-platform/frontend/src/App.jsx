import React, { useState, useEffect, useRef } from 'react';
import { createChart } from 'lightweight-charts';
import axios from 'axios';
import './App.css';
import { Button, Input, Select, Table, Modal, Form, message } from 'antd';
import AdminPanel from './AdminPanel';

const { Option } = Select;

const App = () => {
    const [symbols, setSymbols] = useState(['BTC-USDT', 'ETH-USDT']);
    const [newSymbol, setNewSymbol] = useState('');
    const [signals, setSignals] = useState([]);
    const [livePrices, setLivePrices] = useState({});
    const chartContainerRef = useRef(null);
    const chartRef = useRef(null);
    const [timeframe, setTimeframe] = useState('1H');
    const [isAdminModalVisible, setIsAdminModalVisible] = useState(false);

    useEffect(() => {
        const fetchSignals = async () => {
            const allSignals = [];
            for (const symbol of symbols) {
                try {
                    const response = await axios.get(`http://localhost:8000/signals/${symbol}`);
                    allSignals.push(...response.data);
                } catch (error) {
                    console.error(`خطا در دریافت سیگنال ${symbol}:`, error);
                }
            }
            setSignals(allSignals);
        };

        const wsConnections = symbols.map(symbol => {
            const ws = new WebSocket(`ws://localhost:8000/ws/price/${symbol}`);
            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                setLivePrices(prev => ({ ...prev, [data.symbol]: data.price }));
            };
            return ws;
        });

        const fetchKlines = async () => {
            if (chartContainerRef.current && symbols[0]) {
                const response = await axios.get(`http://localhost:8000/klines/${symbols[0]}/${INTERVALS[timeframe]}`);
                const data = response.data.map(d => ({
                    time: new Date(d.time).getTime() / 1000,
                    open: d.open,
                    high: d.high,
                    low: d.low,
                    close: d.close
                }));
                if (!chartRef.current) {
                    chartRef.current = createChart(chartContainerRef.current, {
                        width: 800,
                        height: 400,
                        layout: { background: { color: '#1E1E1E' }, textColor: '#FFFFFF' },
                        localization: { locale: 'fa-IR', timeFormatter: time => new Date(time * 1000).toLocaleString('fa-IR') }
                    });
                    const candlestickSeries = chartRef.current.addCandlestickSeries();
                    candlestickSeries.setData(data);
                }
            }
        };

        fetchSignals();
        fetchKlines();
        const interval = setInterval(fetchSignals, 60000);

        return () => {
            wsConnections.forEach(ws => ws.close());
            clearInterval(interval);
        };
    }, [symbols, timeframe]);

    const handleAddSymbol = () => {
        if (newSymbol && !symbols.includes(newSymbol)) {
            setSymbols([...symbols, newSymbol]);
            setNewSymbol('');
        }
    };

    const handleRemoveSymbol = (symbol) => {
        setSymbols(symbols.filter(s => s !== symbol));
    };

    const columns = [
        { title: 'نوع سیگنال', dataIndex: 'نوع سیگنال', key: 'نوع سیگنال' },
        { title: 'نماد', dataIndex: 'نماد', key: 'نماد' },
        { title: 'زمان (شمسی)', dataIndex: 'زمان (شمسی)', key: 'زمان (شمسی)' },
        { title: 'قیمت لحظه‌ای', dataIndex: 'قیمت لحظه‌ای', key: 'قیمت لحظه‌ای' },
        { title: 'ورود', dataIndex: 'ورود', key: 'ورود' },
        { title: 'حد ضرر', dataIndex: 'حد ضرر', key: 'حد ضرر' },
        { title: 'TP1', dataIndex: 'TP1', key: 'TP1' },
        { title: 'TP2', dataIndex: 'TP2', key: 'TP2' },
        { title: 'TP3', dataIndex: 'TP3', key: 'TP3' },
    ];

    const INTERVALS = { '4H': '4hour', '1H': '1hour', '15m': '15min', '5m': '5min' };

    return (
        <div className="app-container">
            <h1>📊 پلتفرم معاملاتی هوشمند</h1>
            <Button type="primary" onClick={() => setIsAdminModalVisible(true)} style={{ marginBottom: 20 }}>
                پنل مدیریت
            </Button>
            <Modal
                title="پنل مدیریت"
                visible={isAdminModalVisible}
                onCancel={() => setIsAdminModalVisible(false)}
                footer={null}
            >
                <AdminPanel />
            </Modal>
            <div className="watchlist">
                <h2>🧩 واچ‌لیست</h2>
                <div className="symbol-controls">
                    <Input
                        placeholder="نماد جدید (مثال: BNB-USDT)"
                        value={newSymbol}
                        onChange={(e) => setNewSymbol(e.target.value)}
                        style={{ width: 200, marginRight: 10 }}
                    />
                    <Button type="primary" onClick={handleAddSymbol}>افزودن</Button>
                </div>
                <div className="symbol-list">
                    {symbols.map(symbol => (
                        <div key={symbol} className="symbol-item">
                            {symbol}: {livePrices[symbol] || 'در حال بارگذاری...'}
                            <Button danger onClick={() => handleRemoveSymbol(symbol)}>حذف</Button>
                        </div>
                    ))}
                </div>
            </div>
            <div className="controls">
                <Select
                    defaultValue="1H"
                    onChange={setTimeframe}
                    style={{ width: 120 }}
                >
                    <Option value="1H">1 ساعته</Option>
                    <Option value="4H">4 ساعته</Option>
                    <Option value="15m">15 دقیقه</Option>
                    <Option value="5m">5 دقیقه</Option>
                </Select>
            </div>
            <div className="chart-container" ref={chartContainerRef} />
            <div className="signals">
                <h2>🎯 سیگنال‌های معاملاتی</h2>
                <Table
                    columns={columns}
                    dataSource={signals}
                    rowKey="زمان (شمسی)"
                    pagination={false}
                    locale={{ emptyText: 'هیچ سیگنالی یافت نشد' }}
                />
            </div>
        </div>
    );
};

export default App;