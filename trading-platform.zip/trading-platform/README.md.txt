# پلتفرم معاملاتی هوشمند

پلتفرمی حرفه‌ای برای ارائه سیگنال‌های معاملاتی با داده‌های زنده، رابط کاربری راست‌چین شبیه TradingView، ارسال سیگنال به تلگرام، و پنل مدیریت برای افزودن کدها.

## ساختار پروژه
- `backend/`: شامل FastAPI برای منطق سیگنال‌دهی، WebSocket، و مدیریت کدها.
- `frontend/`: شامل React برای رابط کاربری و پنل مدیریت.

## پیش‌نیازها
- Python 3.8+
- Node.js 16+
- حساب KuCoin برای WebSocket
- بات تلگرام

## نصب و اجرا
### 1. Back-end
1. وارد پوشه `backend` شوید:
   ```bash
   cd backend
   ```
2. پکیج‌ها را نصب کنید:
   ```bash
   pip install -r requirements.txt
   ```
3. توکن‌های `TELEGRAM_TOKEN`, `TELEGRAM_CHAT_ID`, و `your_kucoin_token` را در `api.py` جایگزین کنید.
4. رمز عبور مدیریت را در `api.py` تنظیم کنید (`your_admin_password`).
5. سرور را اجرا کنید:
   ```bash
   uvicorn api:app --host 0.0.0.0 --port 8000
   ```

### 2. Front-end
1. وارد پوشه `frontend` شوید:
   ```bash
   cd frontend
   ```
2. پکیج‌ها را نصب کنید:
   ```bash
   npm install
   ```
3. پروژه را اجرا کنید:
   ```bash
   npm start
   ```

### استفاده از پنل مدیریت
1. در رابط کاربری، روی "پنل مدیریت" کلیک کنید.
2. کد خود را کپی‌پیست کنید، هدف (backend/frontend) و بخش (functions/components) را انتخاب کنید.
3. رمز عبور مدیریت را وارد کنید (`your_admin_password`).
4. روی "ذخیره کد" کلیک کنید تا کد در فایل مناسب ذخیره شود.

## هاستینگ
- **Back-end**: روی Heroku یا AWS EC2 دیپلوی کنید.
- **Front-end**: روی Vercel یا Netlify دیپلوی کنید.

## ارتقا
- برای اخبار، endpoint `/news` را با NewsAPI و هوش مصنوعی گسترش دهید.
- برای انتشار در یوتیوب/اینستاگرام، اسکریپت‌های مربوطه را اضافه کنید.