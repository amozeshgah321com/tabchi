import ast
import os

def validate_python_code(code: str) -> bool:
    try:
        ast.parse(code)
        return True
    except SyntaxError:
        return False

def validate_js_code(code: str) -> bool:
    # اعتبارسنجی ساده برای JSX/CSS
    return True  # برای تولید باید ابزارهایی مثل ESLint اضافه بشه

def update_code(code: str, target: str, section: str):
    if target == "backend" and section == "functions":
        if not validate_python_code(code):
            raise ValueError("سینتکس کد پایتون نامعتبر است")
        with open("api.py", "a", encoding="utf-8") as f:
            f.write("\n" + code + "\n")
    elif target == "frontend" and section == "components":
        if not validate_js_code(code):
            raise ValueError("سینتکس کد JSX/CSS نامعتبر است")
        with open("../frontend/src/App.jsx", "a", encoding="utf-8") as f:
            f.write("\n" + code + "\n")
    else:
        raise ValueError("هدف یا بخش نامعتبر است")