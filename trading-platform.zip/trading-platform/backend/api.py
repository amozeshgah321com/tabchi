from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import requests
import jdatetime
import datetime
import json
import asyncio
import websocket
import threading
from telegram import Bot
import ta
import numpy as np
from pydantic import BaseModel
from code_manager import update_code

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# تنظیمات تلگرام
TELEGRAM_TOKEN = "your_telegram_bot_token"
TELEGRAM_CHAT_ID = "your_chat_id"
bot = Bot(token=TELEGRAM_TOKEN)

# تنظیمات KuCoin
PAIR = 'BTC-USDT'
INTERVALS = {'4H': '4hour', '1H': '1hour', '15m': '15min', '5m': '5min'}
LIMIT = 120

async def send_telegram_message(message):
    await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)

@app.get("/klines/{symbol}/{interval}")
async def get_klines(symbol: str, interval: str, limit: int = 120):
    url = f"https://api.kucoin.com/api/v1/market/candles?type={interval}&symbol={symbol}&limit={limit}"
    try:
        resp = requests.get(url)
        resp.raise_for_status()
        data = resp.json()['data']
        if not data:
            raise ValueError("No data returned from API")
    except Exception as e:
        return {"error": str(e)}
    df = pd.DataFrame(data, columns=['time', 'open', 'close', 'high', 'low', 'vol', 'turnover'])
    df = df.iloc[::-1].reset_index(drop=True)
    df[['open', 'close', 'high', 'low']] = df[['open', 'close', 'high', 'low']].astype(float)
    df['time'] = pd.to_datetime(df['time'], unit='ms')
    return df.to_dict(orient="records")

def detect_structure(df):
    swings = []
    window_before = 120
    window_after = 5
    start_idx = window_before
    end_idx = len(df) - window_after - 1
    for i in range(start_idx, end_idx + 1):
        high = df['high'][i]
        low = df['low'][i]
        before_highs = df['high'][i - window_before:i]
        after_highs = df['high'][i + 1:i + window_after + 1]
        if all(high > h for h in before_highs) and all(high > h for h in after_highs):
            swings.append((df['time'][i], 'HH', high))
        before_lows = df['low'][i - window_before:i]
        after_lows = df['low'][i + 1:i + window_after + 1]
        if all(low < l for l in before_lows) and all(low < l for l in after_lows):
            swings.append((df['time'][i], 'LL', low))
    return swings

def detect_trend(swings):
    trend = 'RANGE'
    last_hhs = [s[2] for s in swings if s[1] == 'HH']
    last_lls = [s[2] for s in swings if s[1] == 'LL']
    if len(last_hhs) >= 2 and last_hhs[-1] > last_hhs[-2]:
        trend = 'UP'
    elif len(last_lls) >= 2 and last_lls[-1] < last_lls[-2]:
        trend = 'DOWN'
    return trend

def detect_bos(df):
    latest_close = df['close'].iloc[-1]
    prev_high = df['high'].iloc[-2]
    prev_low = df['low'].iloc[-2]
    latest_high = df['high'].iloc[-1]
    latest_low = df['low'].iloc[-1]
    if df['close'].iloc[-2] < df['open'].iloc[-2] and df['close'].iloc[-1] > df['open'].iloc[-1] and latest_high > prev_high:
        return 'CHoCH-UP'
    elif df['close'].iloc[-2] > df['open'].iloc[-2] and df['close'].iloc[-1] < df['open'].iloc[-1] and latest_low < prev_low:
        return 'CHoCH-DOWN'
    if latest_close > prev_high:
        return 'BOS-UP'
    elif latest_close < prev_low:
        return 'BOS-DOWN'
    return 'NO'

def detect_order_block(df, direction):
    for i in range(len(df)-2, 1, -1):
        current = df.iloc[i]
        next_candle = df.iloc[i+1]
        if direction == 'LONG' and current['close'] < current['open'] and next_candle['close'] > next_candle['open']:
            return {
                'ob_low': current['low'],
                'ob_high': current['high'],
                'ob_open': current['open'],
                'ob_close': current['close']
            }
        elif direction == 'SHORT' and current['close'] > current['open'] and next_candle['close'] < next_candle['open']:
            return {
                'ob_low': current['low'],
                'ob_high': current['high'],
                'ob_open': current['open'],
                'ob_close': current['close']
            }
    return None

def confirm_entry(df, direction):
    for i in range(len(df)-3, len(df)):
        b1 = df.iloc[i-1]
        b2 = df.iloc[i]
        if direction == 'LONG' and b1['close'] < b1['open'] and b2['close'] > b2['open']:
            return True
        elif direction == 'SHORT' and b1['close'] > b1['open'] and b2['close'] < b2['open']:
            return True
    return False

def calculate_sl_tp(ob_price, direction, risk_ratio=1.5):
    base_price = ob_price['ob_low'] if direction == 'LONG' else ob_price['ob_high']
    sl = base_price * 0.995 if direction == 'LONG' else base_price * 1.005
    tp = base_price + (base_price - sl) * risk_ratio if direction == 'LONG' else base_price - (sl - base_price) * risk_ratio
    return round(sl, 2), round(tp, 2)

@app.get("/signals/{symbol}")
async def generate_combined_signal(symbol: str):
    df_4h = pd.DataFrame((await get_klines(symbol, INTERVALS['4H'])))
    structure = detect_structure(df_4h)
    trend_maa = detect_trend(structure)
    if trend_maa == 'RANGE':
        return []

    df_1h = pd.DataFrame((await get_klines(symbol, INTERVALS['1H'])))
    bos_maa = detect_bos(df_1h)
    if bos_maa == 'NO':
        return []

    direction = 'LONG' if trend_maa == 'UP' and bos_maa in ['BOS-UP', 'CHoCH-UP'] else \
               'SHORT' if trend_maa == 'DOWN' and bos_maa in ['BOS-DOWN', 'CHoCH-DOWN'] else None
    if not direction:
        return []

    df_15m = pd.DataFrame((await get_klines(symbol, INTERVALS['15m'])))
    ob_data = detect_order_block(df_15m, direction)
    if not ob_data:
        return []

    df_5m = pd.DataFrame((await get_klines(symbol, INTERVALS['5m'])))
    confirm = confirm_entry(df_5m, direction)
    if not confirm:
        return []

    sl, tp = calculate_sl_tp(ob_data, direction)
    entry_price = round(ob_data['ob_low'] if direction == 'LONG' else ob_data['ob_high'], 8)
    sl_price = sl
    tp1 = tp
    tp2 = round(entry_price + (tp - entry_price) * 1.5, 8)
    tp3 = round(entry_price + (tp - entry_price) * 2, 8)

    persian_time = jdatetime.datetime.fromgregorian(datetime=datetime.datetime.now())
    persian_str = persian_time.strftime("%Y/%m/%d - %H:%M")
    signal_type = "📈 خرید" if direction == 'LONG' else "📉 فروش"

    signal = {
        'نوع سیگنال': signal_type,
        'نماد': symbol,
        'زمان (شمسی)': persian_str,
        'قیمت لحظه‌ای': await get_current_price(symbol),
        'ورود': entry_price,
        'حد ضرر': sl_price,
        'TP1': tp1,
        'TP2': tp2,
        'TP3': tp3,
        'روند 4H': trend_maa,
        'BOS 1H': bos_maa
    }

    message = f"{signal_type} | {symbol}\nزمان: {persian_str}\nقیمت: {signal['قیمت لحظه‌ای']}\nورود: {entry_price}\nحد ضرر: {sl_price}\nTP1: {tp1}\nTP2: {tp2}\nTP3: {tp3}"
    await send_telegram_message(message)

    return [signal]

async def get_current_price(symbol: str):
    url = "https://api.kucoin.com/api/v1/market/orderbook/level1"
    params = {"symbol": symbol}
    response = requests.get(url, params=params)
    data = response.json()
    if data.get("code") == "200000" and "data" in data:
        return float(data["data"]["price"])
    else:
        price_df = pd.DataFrame((await get_klines(symbol, "1min", limit=1)))
        if not price_df.empty:
            return price_df["close"].iloc[0]
        return None

@app.websocket("/ws/price/{symbol}")
async def websocket_endpoint(websocket: WebSocket, symbol: str):
    await websocket.accept()
    def on_message(ws, message):
        data = json.loads(message)
        if 'data' in data and 'price' in data['data']:
            asyncio.run(websocket.send_json({'symbol': symbol, 'price': data['data']['price']}))
    ws = websocket.WebSocketApp(
        f"wss://push.kucoin.com/endpoint?token=your_kucoin_token&symbol={symbol}",
        on_message=on_message
    )
    threading.Thread(target=ws.run_forever, daemon=True).start()
    try:
        while True:
            await asyncio.sleep(1)
    except:
        ws.close()

@app.get("/news")
async def get_news():
    url = "https://newsapi.org/v2/everything?q=cryptocurrency&apiKey=your_newsapi_key"
    response = requests.get(url)
    articles = response.json().get("articles", [])
    summaries = []
    for article in articles[:5]:
        summary = f"عنوان: {article['title']}\nخلاصه: {article['description'][:100]}..."
        summaries.append(summary)
    return summaries

# مدل برای دریافت کد
class CodeUpdate(BaseModel):
    code: str
    target: str  # 'backend' یا 'frontend'
    section: str  # مثلا 'functions' برای api.py یا 'components' برای App.jsx
    password: str

# پنل مدیریت: ذخیره کد جدید
@app.post("/admin/update-code")
async def update_code_endpoint(code_update: CodeUpdate):
    if code_update.password != "your_admin_password":
        raise HTTPException(status_code=401, detail="رمز عبور اشتباه است")
    try:
        update_code(code_update.code, code_update.target, code_update.section)
        return {"message": "کد با موفقیت به‌روزرسانی شد"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"خطا در به‌روزرسانی کد: {str(e)}")